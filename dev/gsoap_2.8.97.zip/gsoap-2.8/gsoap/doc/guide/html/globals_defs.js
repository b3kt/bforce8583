var globals_defs =
[
    [ "c", "globals_defs.html", null ],
    [ "d", "globals_defs_d.html", null ],
    [ "f", "globals_defs_f.html", null ],
    [ "l", "globals_defs_l.html", null ],
    [ "m", "globals_defs_m.html", null ],
    [ "s", "globals_defs_s.html", null ],
    [ "t", "globals_defs_t.html", null ],
    [ "u", "globals_defs_u.html", null ],
    [ "w", "globals_defs_w.html", null ]
];