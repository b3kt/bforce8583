var group__group__header =
[
    [ "SOAP_ENV__Header", "struct_s_o_a_p___e_n_v_____header.html", null ],
    [ "soap_header", "group__group__header.html#ga08d35d1900a1982fdde6f78e43fc9635", null ]
];