var struct__xop_____include =
[
    [ "__ptr", "struct__xop_____include.html#ab4388e79bc98595fefbde2fbcf5489ba", null ],
    [ "__size", "struct__xop_____include.html#a92be7a45ca282feee3a53fedf5c3a405", null ],
    [ "id", "struct__xop_____include.html#a378e555a35df041c14d0f767dd128c20", null ],
    [ "options", "struct__xop_____include.html#a894a54df2d052989ff2c20d344f56c91", null ],
    [ "type", "struct__xop_____include.html#a0d70af0d2c123766ce188cf2dd15833a", null ]
];